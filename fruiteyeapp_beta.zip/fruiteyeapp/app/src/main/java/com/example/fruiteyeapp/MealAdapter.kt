package com.example.fruiteyeapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class MealAdapter(
    private val onDeleteClick: (Meal) -> Unit // Lambda para manejar el click de eliminación
) : ListAdapter<Meal, MealAdapter.MealViewHolder>(MealDiffCallback()) {

    class MealViewHolder(itemView: View, private val onDeleteClick: (Meal) -> Unit) : RecyclerView.ViewHolder(itemView) {
        private val tvType: TextView = itemView.findViewById(R.id.tv_meal_type)
        private val tvDesc: TextView = itemView.findViewById(R.id.tv_description)
        private val tvCalories: TextView = itemView.findViewById(R.id.tv_calories)
        private val btnDelete: Button = itemView.findViewById(R.id.btn_delete_meal)

        fun bind(meal: Meal) {
            tvType.text = "Tipo: ${meal.mealType}"
            tvDesc.text = "Descripción: ${meal.description}"
            tvCalories.text = "Calorías: ${meal.calories}"

            // Configuración del OnClickListener para el botón de eliminar
            btnDelete.setOnClickListener {
                // Llamamos a la lambda pasando la comida actual
                onDeleteClick(meal)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MealViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_meal, parent, false)
        return MealViewHolder(view, onDeleteClick)
    }

    override fun onBindViewHolder(holder: MealViewHolder, position: Int) {
        val meal = getItem(position)
        holder.bind(meal)
    }
}

class MealDiffCallback : DiffUtil.ItemCallback<Meal>() {
    override fun areItemsTheSame(oldItem: Meal, newItem: Meal): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Meal, newItem: Meal): Boolean {
        return oldItem == newItem
    }
}