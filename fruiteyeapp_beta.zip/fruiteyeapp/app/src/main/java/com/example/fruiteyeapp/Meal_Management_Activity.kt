package com.example.fruiteyeapp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch
import java.util.*

class MealManagementActivity : AppCompatActivity() {
    private lateinit var repository: MealRepository
    private lateinit var mealAdapter: MealAdapter
    private lateinit var bottomNavigation: BottomNavigationView

    companion object {
        const val REQUEST_SCAN_FOOD = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meal_management)

        repository = MealRepository(this)
        setupUI()
        setupBottomNavigation()
        setupMealTypeSpinner()
        setupScanButton()
        loadMeals()
    }

    private fun setupUI() {
        // Configurar RecyclerView para las comidas
        val rvMeals = findViewById<RecyclerView>(R.id.rv_meals)
        mealAdapter = MealAdapter { meal -> deleteMeal(meal) }
        rvMeals.layoutManager = LinearLayoutManager(this)
        rvMeals.adapter = mealAdapter

        // Configurar Botones
        findViewById<Button>(R.id.btn_save_meal).setOnClickListener {
            saveMeal()
        }

        findViewById<Button>(R.id.btn_delete_meals_by_type).setOnClickListener {
            val mealTypeToDelete = findViewById<AutoCompleteTextView>(R.id.spinner_meal_type).text.toString()
            deleteMealsByType(mealTypeToDelete)
        }
    }

    private fun setupMealTypeSpinner() {
        val autoCompleteTextView = findViewById<AutoCompleteTextView>(R.id.spinner_meal_type)
        val mealTypes = resources.getStringArray(R.array.meal_types)

        // Si no tienes un array en resources, puedes usar esta línea en su lugar:
        // val mealTypes = arrayOf("Desayuno", "Almuerzo", "Cena", "Snack")

        // Usar el adaptador con un layout que funcione mejor para dropdown
        val adapter = ArrayAdapter(this, R.layout.dropdown_item, mealTypes)
        autoCompleteTextView.setAdapter(adapter)

        // Establecer un valor predeterminado si es necesario
        if (autoCompleteTextView.text.isEmpty()) {
            autoCompleteTextView.setText(mealTypes[0], false)
        }
    }

    private fun setupScanButton() {
        // Configurar el botón de escanear comida
        findViewById<MaterialButton>(R.id.btn_scan_food).setOnClickListener {
            // Iniciar la actividad de escaneo de comida
            val intent = Intent(this, MainActivity::class.java)
            startActivityForResult(intent, REQUEST_SCAN_FOOD)
        }
    }

    private fun setupBottomNavigation() {
        bottomNavigation = findViewById(R.id.bottom_navigation)

        // Marcar el ítem de comidas como seleccionado
        bottomNavigation.selectedItemId = R.id.navigation_meals

        // Configurar el listener para la navegación
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_meals -> {
                    // Ya estamos en esta pantalla, no hacemos nada
                    true
                }
                R.id.navigation_progress -> {
                    // Navegar a la pantalla de progreso
                    val intent = Intent(this, ProgressActivity::class.java)
                    startActivity(intent)
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                    finish() // Opcional: cerrar esta actividad
                    true
                }
                R.id.navigation_profile -> {
                    // Navegar a la pantalla de perfil
                    val intent = Intent(this, ProfileActivity::class.java)
                    startActivity(intent)
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                    finish() // Opcional: cerrar esta actividad
                    true
                }
                else -> false
            }
        }
    }

    private fun saveMeal() {
        // Obtener el tipo de comida desde el AutoCompleteTextView
        val mealType = findViewById<AutoCompleteTextView>(R.id.spinner_meal_type).text.toString()
        val description = findViewById<TextInputEditText>(R.id.et_food_description).text.toString()
        val caloriesText = findViewById<TextInputEditText>(R.id.et_calories).text.toString()

        if (description.isEmpty() || caloriesText.isEmpty() || mealType.isEmpty()) {
            Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        val calories = caloriesText.toIntOrNull() ?: run {
            Toast.makeText(this, "Ingresa un valor válido para las calorías", Toast.LENGTH_SHORT).show()
            return
        }

        val meal = Meal(
            mealType = mealType,
            description = description,
            calories = calories
        )

        lifecycleScope.launch {
            repository.insertMeal(meal)
            clearInputs()
            loadMeals()
            Toast.makeText(this@MealManagementActivity, "Comida guardada", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearInputs() {
        findViewById<TextInputEditText>(R.id.et_food_description).text?.clear()
        findViewById<TextInputEditText>(R.id.et_calories).text?.clear()
    }

    private fun deleteMeal(meal: Meal) {
        lifecycleScope.launch {
            meal.id?.let { repository.deleteMeal(it) }
            loadMeals()
            Toast.makeText(this@MealManagementActivity, "Comida eliminada", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteMealsByType(mealType: String) {
        lifecycleScope.launch {
            repository.deleteMealsByType(mealType)
            loadMeals()
            Toast.makeText(
                this@MealManagementActivity,
                "Comidas de tipo $mealType eliminadas",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun loadMeals() {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startOfDay = calendar.timeInMillis

        lifecycleScope.launch {
            val meals = repository.getMealsForDay(startOfDay)
            mealAdapter.submitList(meals)
        }
    }

    // Maneja el resultado de la actividad de escaneo
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_SCAN_FOOD && resultCode == Activity.RESULT_OK && data != null) {
            // Recupera la información de la comida escaneada
            val foodName = data.getStringExtra("FOOD_NAME") ?: ""
            val calories = data.getIntExtra("CALORIES", 0)

            // Actualiza los campos con la información recibida
            findViewById<TextInputEditText>(R.id.et_food_description).setText(foodName)
            findViewById<TextInputEditText>(R.id.et_calories).setText(calories.toString())

            Toast.makeText(this, "Alimento detectado: $foodName", Toast.LENGTH_SHORT).show()
        }
    }
}