package com.example.fruiteyeapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class CalorieSummaryAdapter(
    private val onDeleteClick: (CalorieSummary) -> Unit
) : ListAdapter<CalorieSummary, CalorieSummaryAdapter.CalorieSummaryViewHolder>(CalorieSummaryDiffCallback()) {

    class CalorieSummaryViewHolder(itemView: View, private val onDeleteClick: (CalorieSummary) -> Unit) : RecyclerView.ViewHolder(itemView) {
        private val mealTypeTextView: TextView = itemView.findViewById(R.id.tv_meal_type)
        private val totalCaloriesTextView: TextView = itemView.findViewById(R.id.tv_total_calories)
        private val mealListTextView: TextView = itemView.findViewById(R.id.tv_meal_list)
        private val deleteButton: Button = itemView.findViewById(R.id.btn_delete_meal)

        fun bind(summary: CalorieSummary) {
            mealTypeTextView.text = summary.mealType
            totalCaloriesTextView.text = "${summary.totalCalories} kcal"

            val mealDetails = summary.meals.joinToString("\n") {
                "• ${it.description} - ${it.calories} kcal"
            }

            mealListTextView.text = mealDetails

            // Configurar el botón de eliminar
            deleteButton.setOnClickListener {
                onDeleteClick(summary)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CalorieSummaryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_calorie_summary, parent, false)
        return CalorieSummaryViewHolder(view, onDeleteClick)
    }

    override fun onBindViewHolder(holder: CalorieSummaryViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
}

class CalorieSummaryDiffCallback : DiffUtil.ItemCallback<CalorieSummary>() {
    override fun areItemsTheSame(oldItem: CalorieSummary, newItem: CalorieSummary): Boolean {
        return oldItem.mealType == newItem.mealType
    }

    override fun areContentsTheSame(oldItem: CalorieSummary, newItem: CalorieSummary): Boolean {
        return oldItem == newItem
    }
}