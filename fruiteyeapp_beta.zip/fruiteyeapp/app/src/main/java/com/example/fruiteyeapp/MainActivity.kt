package com.example.fruiteyeapp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var resultText: TextView
    private lateinit var loadingIndicator: ProgressBar

    private var currentPhotoPath: String = ""

    companion object {
        private const val PICK_IMAGE_REQUEST = 1
        private const val CAMERA_REQUEST = 2
        private const val PERMISSION_REQUEST = 3

        // En una aplicación real, esto debería venir de BuildConfig
        private const val API_KEY = "kAeCQ5leWbAIzElqgxtM"
        private const val MODEL_ENDPOINT = "https://detect.roboflow.com/fruits_det-ursdl/4"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val galleryButton: Button = findViewById(R.id.galleryButton)
        val captureButton: Button = findViewById(R.id.captureButton)
        imageView = findViewById(R.id.imageView)
        resultText = findViewById(R.id.resultText)
        loadingIndicator = findViewById(R.id.loadingIndicator)

        loadingIndicator.visibility = View.GONE

        // Verificar permisos al iniciar
        checkPermissions()

        galleryButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, PICK_IMAGE_REQUEST)
        }

        captureButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                dispatchTakePictureIntent()
            } else {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CAMERA),
                    PERMISSION_REQUEST
                )
            }
        }
    }

    private fun checkPermissions() {
        val permissions = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )

        val permissionsToRequest = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsToRequest, PERMISSION_REQUEST)
        }
    }

    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(packageManager)?.also {
                val photoFile: File? = try {
                    createImageFile()
                } catch (ex: IOException) {
                    Toast.makeText(this, "Error al crear el archivo de imagen", Toast.LENGTH_SHORT).show()
                    null
                }

                photoFile?.also {
                    val photoURI: Uri = FileProvider.getUriForFile(
                        this,
                        "com.example.fruiteyeapp.fileprovider",
                        it
                    )
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    startActivityForResult(takePictureIntent, CAMERA_REQUEST)
                }
            } ?: run {
                Toast.makeText(this, "No se encontró una aplicación de cámara", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun createImageFile(): File {
        val timeStamp: String = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.getDefault()).format(java.util.Date())
        val storageDir: File? = getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "JPEG_${timeStamp}_",
            ".jpg",
            storageDir
        ).apply {
            currentPhotoPath = absolutePath
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                PICK_IMAGE_REQUEST -> {
                    val imageUri: Uri? = data?.data
                    imageUri?.let {
                        imageView.setImageURI(it)
                        val imageFile = getFileFromUri(it)
                        imageFile?.let { file -> processImage(file) }
                    }
                }
                CAMERA_REQUEST -> {
                    val imageFile = File(currentPhotoPath)
                    if (imageFile.exists()) {
                        val bitmap = BitmapFactory.decodeFile(currentPhotoPath)
                        imageView.setImageBitmap(bitmap)
                        processImage(imageFile)
                    } else {
                        Toast.makeText(this, "No se pudo acceder a la imagen", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                Toast.makeText(this, "Permisos concedidos", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Se requieren permisos para usar todas las funciones", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun getFileFromUri(uri: Uri): File? {
        val inputStream: InputStream? = contentResolver.openInputStream(uri)
        val file = File(cacheDir, "selectedImage.jpg")
        inputStream?.use { input ->
            file.outputStream().use { output ->
                input.copyTo(output)
            }
        }
        return file
    }

    private fun processImage(imageFile: File) {
        if (isInternetAvailable()) {
            uploadImageToRoboflow(imageFile)
        } else {
            // Mostrar un diálogo al usuario
            AlertDialog.Builder(this)
                .setTitle("Sin conexión a Internet")
                .setMessage("No se detectó conexión a Internet. ¿Deseas intentar la detección local (menos precisa) o intentar más tarde?")
                .setPositiveButton("Detección local") { _, _ ->
                    processImageLocally(imageFile)
                }
                .setNegativeButton("Cancelar") { dialog, _ ->
                    dialog.dismiss()
                }
                .show()
        }
    }

    private fun isInternetAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val networkCapabilities = connectivityManager.activeNetwork ?: return false
            val actNw = connectivityManager.getNetworkCapabilities(networkCapabilities) ?: return false
            return when {
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                else -> false
            }
        } else {
            @Suppress("DEPRECATION")
            val networkInfo = connectivityManager.activeNetworkInfo
            @Suppress("DEPRECATION")
            return networkInfo != null && networkInfo.isConnected
        }
    }

    private fun uploadImageToRoboflow(imageFile: File) {
        loadingIndicator.visibility = View.VISIBLE
        resultText.text = "Analizando imagen..."

        val fullUrl = "$MODEL_ENDPOINT?api_key=$API_KEY"

        val client = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()

        val mediaType = "image/*".toMediaTypeOrNull()
        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", imageFile.name, imageFile.asRequestBody(mediaType))
            .build()

        val request = Request.Builder()
            .url(fullUrl)
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    loadingIndicator.visibility = View.GONE
                    resultText.text = "Error: ${e.message}"

                    // Mostrar un mensaje más amigable según el tipo de error
                    when {
                        e is java.net.UnknownHostException ->
                            Toast.makeText(this@MainActivity, "No hay conexión a internet", Toast.LENGTH_SHORT).show()
                        e is java.net.SocketTimeoutException ->
                            Toast.makeText(this@MainActivity, "La conexión tardó demasiado tiempo", Toast.LENGTH_SHORT).show()
                        else ->
                            Toast.makeText(this@MainActivity, "Error al procesar la imagen", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string()

                runOnUiThread {
                    loadingIndicator.visibility = View.GONE

                    if (!response.isSuccessful) {
                        resultText.text = "Error: ${response.code} - ${response.message}"
                        return@runOnUiThread
                    }

                    try {
                        val json = JSONObject(responseBody ?: "{}")
                        processPredictions(json)
                    } catch (e: Exception) {
                        resultText.text = "Error al procesar la respuesta: ${e.message}"
                    }
                }
            }
        })
    }

    private fun processPredictions(json: JSONObject) {
        val predictions = json.optJSONArray("predictions")
        val resultado = StringBuilder()

        if (predictions == null || predictions.length() == 0) {
            resultText.text = "No se detectaron frutas en la imagen."
            return
        }

        for (i in 0 until predictions.length()) {
            val pred = predictions.getJSONObject(i)
            val clase = pred.getString("class")
            val confidence = pred.optDouble("confidence", 0.0) * 100

            if ("-" in clase) {
                val partes = clase.split("-")
                val nombre = partes[0].trim().capitalize(Locale.getDefault())
                val calorias = partes[1].replace("calories", "").trim()
                resultado.append("🍎 Fruta: $nombre\n")
                resultado.append("🔥 Calorías: $calorias\n")
                resultado.append("✓ Confianza: ${String.format("%.1f", confidence)}%\n\n")
            } else {
                resultado.append("Detectado: $clase\n")
                resultado.append("Confianza: ${String.format("%.1f", confidence)}%\n\n")
            }
        }

        resultText.text = resultado.toString()
    }

    private fun processImageLocally(imageFile: File) {
        // Esta es una versión simulada. En una implementación real, usarías TensorFlow Lite
        resultText.text = "Procesando localmente... (Esta es una versión simulada)"

        // Simular un retraso y mostrar un resultado básico
        Handler(Looper.getMainLooper()).postDelayed({
            resultText.text = "Detección local (simulada):\n" +
                    "🍎 Fruta: Manzana\n" +
                    "🔥 Calorías: aproximadamente 52 kcal\n" +
                    "⚠️ Para resultados más precisos, conéctate a Internet"
        }, 1500)

        // En una implementación real, aquí usarías TensorFlow Lite
    }
}