package com.example.fruiteyeapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.*

class ProgressActivity : AppCompatActivity() {

    private lateinit var tvWeightValue: TextView
    private lateinit var viewChartPlaceholder: View
    private lateinit var tvChartLabel: TextView
    private lateinit var btnUpdateProgress: Button
    private lateinit var bottomNavigation: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progress)

        initViews()
        setupBottomNavigation()
        loadProgressData()
        setupListeners()
    }

    private fun initViews() {
        tvWeightValue = findViewById(R.id.tv_weight_value)
        viewChartPlaceholder = findViewById(R.id.view_chart_placeholder)
        tvChartLabel = findViewById(R.id.tv_chart_label)
        btnUpdateProgress = findViewById(R.id.btn_update_progress)
        bottomNavigation = findViewById(R.id.bottom_navigation)
    }

    private fun setupBottomNavigation() {
        bottomNavigation.selectedItemId = R.id.navigation_progress

        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_meals -> {
                    val intent = Intent(this, MealManagementActivity::class.java)
                    startActivity(intent)
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                    finish()
                    true
                }
                R.id.navigation_progress -> {
                    true
                }
                R.id.navigation_profile -> {
                    val intent = Intent(this, ProfileActivity::class.java)
                    startActivity(intent)
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                    finish()
                    true
                }
                else -> false
            }
        }
    }

    private fun loadProgressData() {
        val prefs = getSharedPreferences(ProfileActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val currentWeight = prefs.getFloat(ProfileActivity.KEY_WEIGHT, 0f)
        val bmi = prefs.getFloat(ProfileActivity.KEY_BMI, 0f)
        val lastUpdate = prefs.getLong(ProfileActivity.KEY_LAST_UPDATE, 0)

        // Mostrar el peso actual y detalles adicionales
        if (currentWeight > 0) {
            // Mostrar peso actual
            tvWeightValue.text = String.format("%.1f kg", currentWeight)

            // Información adicional en el chart label
            val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            val dateString = if (lastUpdate > 0) {
                dateFormat.format(Date(lastUpdate))
            } else {
                "fecha desconocida"
            }

            // Si tenemos el IMC, lo mostramos junto con el peso
            if (bmi > 0) {
                val bmiCategory = when {
                    bmi < 18.5 -> "Bajo peso"
                    bmi < 25 -> "Normal"
                    bmi < 30 -> "Sobrepeso"
                    else -> "Obesidad"
                }
                tvChartLabel.text = "IMC: %.1f (%s)\nÚltima actualización: %s".format(bmi, bmiCategory, dateString)
            } else {
                tvChartLabel.text = "Última actualización: $dateString"
            }

            // Cargar datos para mostrar tendencia
            loadWeightTrend()
        } else {
            tvWeightValue.text = "No hay datos"
            tvChartLabel.text = "Aún no has registrado tu peso"
        }
    }

    private fun loadWeightTrend() {
        // Obtener el historial de pesos
        val history = getWeightHistory()

        // Si tenemos suficientes datos, mostrar alguna información de tendencia
        if (history.size >= 2) {
            val firstWeight = history.first().weight
            val lastWeight = history.last().weight
            val difference = lastWeight - firstWeight

            val trendText = when {
                difference > 0 -> "Tendencia: ↗ Has aumentado %.1f kg"
                difference < 0 -> "Tendencia: ↘ Has reducido %.1f kg"
                else -> "Tendencia: → Tu peso se ha mantenido estable"
            }

            // Actualizar el texto del placeholder con la tendencia
            val weightView = findViewById<TextView>(R.id.tv_weight_title)
            weightView.text = "Peso Actual (${trendText.format(Math.abs(difference))})"
        }
    }

    private fun setupListeners() {
        btnUpdateProgress.setOnClickListener {
            showUpdateWeightDialog()
        }
    }

    private fun showUpdateWeightDialog() {
        // Crear un EditText programáticamente para el diálogo
        val etWeight = TextInputEditText(this)
        etWeight.hint = "Peso en kg"
        etWeight.inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL

        // Obtener peso actual para mostrar como valor inicial
        val prefs = getSharedPreferences(ProfileActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val currentWeight = prefs.getFloat(ProfileActivity.KEY_WEIGHT, 0f)
        if (currentWeight > 0) {
            etWeight.setText(currentWeight.toString())
        }

        // Crear y mostrar el diálogo
        AlertDialog.Builder(this)
            .setTitle("Actualizar Peso")
            .setView(etWeight)
            .setPositiveButton("Guardar") { _, _ ->
                val newWeightText = etWeight.text.toString()
                val newWeight = newWeightText.toFloatOrNull()

                if (newWeight != null && newWeight > 0) {
                    // Guardar el nuevo peso
                    saveNewWeight(newWeight)

                    // Recargar los datos
                    loadProgressData()

                    Toast.makeText(this, "Peso actualizado a $newWeight kg", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Por favor, ingresa un peso válido", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .setNeutralButton("Perfil Completo") { _, _ ->
                val intent = Intent(this, ProfileActivity::class.java)
                startActivity(intent)
                finish()
            }
            .show()
    }

    private fun saveNewWeight(weight: Float) {
        // Guardar el nuevo peso en SharedPreferences
        val prefs = getSharedPreferences(ProfileActivity.PREFS_NAME, Context.MODE_PRIVATE)
        with(prefs.edit()) {
            putFloat(ProfileActivity.KEY_WEIGHT, weight)
            putLong(ProfileActivity.KEY_LAST_UPDATE, System.currentTimeMillis())

            // Recalcular el IMC si tenemos la altura
            val height = prefs.getInt(ProfileActivity.KEY_HEIGHT, 0)
            if (height > 0) {
                val bmi = calculateBMI(weight, height)
                putFloat(ProfileActivity.KEY_BMI, bmi)
            }

            apply()
        }

        // Guardar en el historial de progreso
        saveProgressData(weight)
    }

    private fun calculateBMI(weight: Float, height: Int): Float {
        val heightInMeters = height / 100f
        return weight / (heightInMeters * heightInMeters)
    }

    private fun saveProgressData(weight: Float) {
        val prefs = getSharedPreferences(ProfileActivity.PROGRESS_PREFS, Context.MODE_PRIVATE)
        val progressHistory = prefs.getString(ProfileActivity.KEY_WEIGHT_HISTORY, "")

        val newEntry = "${System.currentTimeMillis()},${weight}"
        val updatedHistory = if (progressHistory.isNullOrEmpty()) {
            newEntry
        } else {
            "$progressHistory;$newEntry"
        }

        with(prefs.edit()) {
            putString(ProfileActivity.KEY_WEIGHT_HISTORY, updatedHistory)
            apply()
        }
    }

    // Clase para representar un punto de datos del progreso
    data class ProgressPoint(
        val timestamp: Long,
        val weight: Float
    )

    private fun getWeightHistory(): List<ProgressPoint> {
        val prefs = getSharedPreferences(ProfileActivity.PROGRESS_PREFS, Context.MODE_PRIVATE)
        val historyString = prefs.getString(ProfileActivity.KEY_WEIGHT_HISTORY, "")

        if (historyString.isNullOrEmpty()) {
            return emptyList()
        }

        return historyString.split(";").mapNotNull { entry ->
            val parts = entry.split(",")
            if (parts.size == 2) {
                try {
                    val timestamp = parts[0].toLong()
                    val weight = parts[1].toFloat()
                    ProgressPoint(timestamp, weight)
                } catch (e: Exception) {
                    null
                }
            } else {
                null
            }
        }.sortedBy { it.timestamp }  // Ordenar por fecha
    }
}