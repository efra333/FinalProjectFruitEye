package com.example.fruiteyeapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.textfield.TextInputEditText

class ProfileActivity : AppCompatActivity() {

    private lateinit var etWeight: TextInputEditText
    private lateinit var etHeight: TextInputEditText
    private lateinit var etAge: TextInputEditText
    private lateinit var spinnerGoal: Spinner
    private lateinit var btnSaveProfile: Button
    private lateinit var bottomNavigation: BottomNavigationView
    private lateinit var tvTips: TextView
    private lateinit var btnMoreTips: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        initViews()
        setupSpinner()
        setupBottomNavigation()
        loadProfile()
        setupListeners()
    }

    private fun initViews() {
        etWeight = findViewById(R.id.et_weight)
        etHeight = findViewById(R.id.et_height)
        etAge = findViewById(R.id.et_age)
        spinnerGoal = findViewById(R.id.spinner_goal)
        btnSaveProfile = findViewById(R.id.btn_save_profile)
        bottomNavigation = findViewById(R.id.bottom_navigation)
        tvTips = findViewById(R.id.tv_tips)
        btnMoreTips = findViewById(R.id.btn_more_tips)
    }

    private fun setupBottomNavigation() {
        // Marcar el ítem de perfil como seleccionado
        bottomNavigation.selectedItemId = R.id.navigation_profile

        // Configurar el listener para la navegación
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_meals -> {
                    // Navegar a la pantalla de comidas
                    val intent = Intent(this, MealManagementActivity::class.java)
                    startActivity(intent)
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                    finish() // Opcional: cerrar esta actividad
                    true
                }
                R.id.navigation_progress -> {
                    // Navegar a la pantalla de progreso
                    val intent = Intent(this, ProgressActivity::class.java)
                    startActivity(intent)
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                    finish() // Opcional: cerrar esta actividad
                    true
                }
                R.id.navigation_profile -> {
                    // Ya estamos en esta pantalla, no hacemos nada
                    true
                }
                else -> false
            }
        }
    }

    private fun setupSpinner() {
        // Usar el array predefinido desde los recursos
        val goalTypes = resources.getStringArray(R.array.goal_types)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, goalTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerGoal.adapter = adapter

        // Añadir listener para mostrar consejos al cambiar el objetivo
        spinnerGoal.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedGoal = parent?.getItemAtPosition(position).toString()
                showTipsForGoal(selectedGoal)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // No es necesario hacer nada aquí
            }
        }
    }

    private fun loadProfile() {
        // Cargar datos guardados previamente usando SharedPreferences
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        val weight = prefs.getFloat(KEY_WEIGHT, 0f)
        val height = prefs.getInt(KEY_HEIGHT, 0)
        val age = prefs.getInt(KEY_AGE, 0)
        val goalIndex = prefs.getInt(KEY_GOAL, 0)
        val goalText = prefs.getString(KEY_GOAL_TEXT, "")

        // Llenar los campos si hay datos guardados
        if (weight > 0) etWeight.setText(weight.toString())
        if (height > 0) etHeight.setText(height.toString())
        if (age > 0) etAge.setText(age.toString())
        if (goalIndex >= 0 && goalIndex < spinnerGoal.adapter.count) {
            spinnerGoal.setSelection(goalIndex)
        }

        // Mostrar consejos basados en el objetivo guardado
        if (!goalText.isNullOrEmpty()) {
            showTipsForGoal(goalText)
        }
    }

    private fun setupListeners() {
        btnSaveProfile.setOnClickListener {
            saveProfile()
        }

        btnMoreTips.setOnClickListener {
            showMoreTipsDialog(spinnerGoal.selectedItem.toString())
        }
    }

    private fun saveProfile() {
        // Validar datos
        val weightText = etWeight.text.toString()
        val heightText = etHeight.text.toString()
        val ageText = etAge.text.toString()

        if (weightText.isEmpty() || heightText.isEmpty() || ageText.isEmpty()) {
            Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        // Convertir y validar datos
        val weight = weightText.toFloatOrNull()
        val height = heightText.toIntOrNull()
        val age = ageText.toIntOrNull()
        val goalIndex = spinnerGoal.selectedItemPosition
        val goalType = spinnerGoal.selectedItem.toString()

        if (weight == null || height == null || age == null) {
            Toast.makeText(this, "Por favor ingresa valores numéricos válidos", Toast.LENGTH_SHORT).show()
            return
        }

        // Guardar datos en SharedPreferences
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        with(prefs.edit()) {
            putFloat(KEY_WEIGHT, weight)
            putInt(KEY_HEIGHT, height)
            putInt(KEY_AGE, age)
            putInt(KEY_GOAL, goalIndex)
            putString(KEY_GOAL_TEXT, goalType)
            // Guardar la fecha actual como punto de referencia para el seguimiento
            putLong(KEY_LAST_UPDATE, System.currentTimeMillis())
            apply()
        }

        // Calcular y guardar el IMC
        val bmi = calculateBMI(weight, height)
        with(prefs.edit()) {
            putFloat(KEY_BMI, bmi)
            apply()
        }

        // Guardar este punto de datos en el historial de progreso
        saveProgressData(weight)

        // Mostrar consejos basados en el objetivo y el IMC
        showTipsForGoal(goalType, bmi)

        Toast.makeText(this, "Perfil guardado exitosamente", Toast.LENGTH_SHORT).show()

        // Mostrar un diálogo con consejos personalizados
        showProfileSavedTipsDialog(goalType, bmi)
    }

    private fun showProfileSavedTipsDialog(goalType: String, bmi: Float) {
        val tips = getDetailedTipsForGoal(goalType, bmi)

        AlertDialog.Builder(this)
            .setTitle("Consejos personalizados")
            .setMessage(tips)
            .setPositiveButton("Ver mi progreso") { _, _ ->
                // Navegar a la pantalla de progreso
                val intent = Intent(this, ProgressActivity::class.java)
                startActivity(intent)
                finish()
            }
            .setNegativeButton("Seguir editando", null)
            .show()
    }

    private fun calculateBMI(weight: Float, height: Int): Float {
        // IMC = peso (kg) / (altura (m))²
        val heightInMeters = height / 100f
        return weight / (heightInMeters * heightInMeters)
    }

    private fun saveProgressData(weight: Float) {
        // Guardar el punto de datos en un historial para mostrar en gráficos
        val prefs = getSharedPreferences(PROGRESS_PREFS, Context.MODE_PRIVATE)
        val progressHistory = prefs.getString(KEY_WEIGHT_HISTORY, "")

        // Formato: timestamp,peso;timestamp,peso;...
        val newEntry = "${System.currentTimeMillis()},${weight}"
        val updatedHistory = if (progressHistory.isNullOrEmpty()) {
            newEntry
        } else {
            "$progressHistory;$newEntry"
        }

        with(prefs.edit()) {
            putString(KEY_WEIGHT_HISTORY, updatedHistory)
            apply()
        }
    }

    private fun showTipsForGoal(goalType: String, bmi: Float = 0f) {
        // Mostrar consejos básicos en el TextView
        val tipText = getBasicTipsForGoal(goalType, bmi)
        tvTips.text = tipText
        tvTips.visibility = View.VISIBLE

        // Hacer visible el botón para más consejos
        btnMoreTips.visibility = View.VISIBLE
    }

    private fun getBasicTipsForGoal(goalType: String, bmi: Float = 0f): String {
        return when (goalType) {
            "Perder peso" -> {
                if (bmi > 0) {
                    when {
                        bmi > 30 -> "Consejo: Para perder peso de forma saludable, combina ejercicio cardio con una dieta baja en calorías pero rica en nutrientes."
                        bmi > 25 -> "Consejo: Intenta reducir las porciones y aumentar la actividad física diaria para lograr un déficit calórico moderado."
                        else -> "Consejo: Tu IMC está en rango normal. Si deseas perder peso, enfócate en tonificar con ejercicios de fuerza y una alimentación balanceada."
                    }
                } else {
                    "Consejo: Para perder peso de forma saludable, crea un pequeño déficit calórico con dieta equilibrada y ejercicio regular."
                }
            }
            "Mantener peso" -> {
                if (bmi > 0) {
                    when {
                        bmi > 25 -> "Consejo: Para mantener un peso saludable, considera primero alcanzar un IMC normal con hábitos que puedas mantener a largo plazo."
                        bmi < 18.5 -> "Consejo: Tu IMC indica bajo peso. Considera aumentar tu ingesta calórica con alimentos nutritivos."
                        else -> "Consejo: Tu IMC está en rango normal. Mantén tu equilibrio actual con una dieta balanceada y actividad física regular."
                    }
                } else {
                    "Consejo: Para mantener tu peso, equilibra las calorías que consumes con las que quemas y mantén una rutina de ejercicio consistente."
                }
            }
            "Ganar peso" -> {
                if (bmi > 0) {
                    when {
                        bmi < 18.5 -> "Consejo: Para ganar peso saludablemente, aumenta gradualmente tu ingesta calórica con alimentos ricos en proteínas y nutrientes."
                        bmi < 25 -> "Consejo: Si quieres ganar masa muscular, combina un superávit calórico moderado con entrenamiento de fuerza."
                        else -> "Consejo: Tu IMC indica sobrepeso. Enfócate en ganar masa muscular con entrenamiento de fuerza y una alimentación rica en proteínas."
                    }
                } else {
                    "Consejo: Para ganar peso saludablemente, aumenta tu ingesta calórica con alimentos nutritivos y complementa con entrenamiento de fuerza."
                }
            }
            "Mejorar condición física" -> {
                if (bmi > 0) {
                    when {
                        bmi > 30 -> "Consejo: Comienza con actividades de bajo impacto como caminar o nadar, y ve aumentando gradualmente la intensidad."
                        bmi > 25 -> "Consejo: Combina cardio con entrenamiento de fuerza para mejorar tu condición física y composición corporal."
                        else -> "Consejo: Tu IMC está en rango normal. Para mejorar tu condición, incluye variedad en tu entrenamiento: fuerza, cardio y flexibilidad."
                    }
                } else {
                    "Consejo: Para mejorar tu condición física, incorpora diferentes tipos de ejercicio (cardio, fuerza, flexibilidad) y mantén una alimentación balanceada."
                }
            }
            else -> "Selecciona un objetivo para ver consejos personalizados."
        }
    }

    private fun getDetailedTipsForGoal(goalType: String, bmi: Float = 0f): String {
        val bmiCategory = when {
            bmi < 18.5 -> "bajo peso"
            bmi < 25 -> "peso normal"
            bmi < 30 -> "sobrepeso"
            else -> "obesidad"
        }

        return when (goalType) {
            "Perder peso" -> {
                """
                CONSEJOS PARA PERDER PESO:
                
                ${if (bmi > 0) "Tu IMC es de ${String.format("%.1f", bmi)}, lo que indica $bmiCategory." else ""}
                
                1. Alimentación:
                   • Crea un déficit calórico moderado (300-500 calorías menos al día)
                   • Aumenta el consumo de proteínas para mantener la masa muscular
                   • Prioriza alimentos integrales y evita los ultraprocesados
                   • Incluye muchas verduras y frutas en tu dieta diaria
                   • Bebe abundante agua (mínimo 2 litros diarios)
                
                2. Ejercicio:
                   • Realiza cardio 3-5 veces por semana (30-45 minutos)
                   • Incluye entrenamiento de fuerza 2-3 veces por semana
                   • Aumenta la actividad diaria: camina más, usa escaleras, etc.
                
                3. Hábitos:
                   • Duerme 7-8 horas para regular hormonas relacionadas con el hambre
                   • Controla el estrés (puede aumentar cortisol y provocar aumento de peso)
                   • Lleva un registro de comidas para mayor conciencia
                   • Establece metas realistas (0.5-1 kg por semana como máximo)
                
                Recuerda: La constancia es más importante que la perfección.
                """.trimIndent()
            }
            "Mantener peso" -> {
                """
                CONSEJOS PARA MANTENER TU PESO:
                
                ${if (bmi > 0) "Tu IMC es de ${String.format("%.1f", bmi)}, lo que indica $bmiCategory." else ""}
                
                1. Alimentación:
                   • Mantén un equilibrio calórico (calorías consumidas = calorías gastadas)
                   • Sigue el principio 80/20: 80% alimentos nutritivos, 20% alimentos placer
                   • Come de manera consciente y presta atención a señales de hambre
                   • Mantén una hidratación adecuada
                
                2. Ejercicio:
                   • Realiza actividad física regular (150 min/semana moderada o 75 min/semana intensa)
                   • Incluye variedad: cardio, fuerza y flexibilidad
                   • Mantén un nivel de actividad diaria consistente
                
                3. Hábitos:
                   • Pésate regularmente (1 vez por semana) para detectar cambios
                   • Ajusta tu ingesta calórica según tu nivel de actividad
                   • Mantén horarios regulares de comidas
                   • Prioriza el descanso adecuado
                
                Recuerda: El mantenimiento del peso es un proceso dinámico que requiere ajustes pequeños pero constantes.
                """.trimIndent()
            }
            "Ganar peso" -> {
                """
                CONSEJOS PARA GANAR PESO SALUDABLEMENTE:
                
                ${if (bmi > 0) "Tu IMC es de ${String.format("%.1f", bmi)}, lo que indica $bmiCategory." else ""}
                
                1. Alimentación:
                   • Crea un superávit calórico moderado (300-500 calorías extra al día)
                   • Aumenta progresivamente la ingesta calórica (no de golpe)
                   • Consume proteínas de alta calidad (1.6-2.2g/kg de peso corporal)
                   • Incluye suficientes carbohidratos y grasas saludables
                   • Realiza 5-6 comidas diarias en lugar de 3 grandes
                
                2. Ejercicio:
                   • Prioriza el entrenamiento de fuerza (3-4 veces por semana)
                   • Enfócate en ejercicios compuestos (sentadillas, peso muerto, press)
                   • Limita el cardio excesivo que puede dificultar el aumento de peso
                   • Asegura descanso adecuado entre entrenamientos (48h por grupo muscular)
                
                3. Hábitos:
                   • Duerme 7-9 horas para favorecer la recuperación muscular
                   • Considera batidos proteicos si te cuesta comer suficiente
                   • Lleva un registro de tu progreso (peso y medidas)
                   • Sé paciente: el aumento de masa muscular es un proceso lento
                
                Recuerda: El objetivo es ganar principalmente masa muscular, no grasa.
                """.trimIndent()
            }
            "Mejorar condición física" -> {
                """
                CONSEJOS PARA MEJORAR TU CONDICIÓN FÍSICA:
                
                ${if (bmi > 0) "Tu IMC es de ${String.format("%.1f", bmi)}, lo que indica $bmiCategory." else ""}
                
                1. Entrenamiento completo:
                   • Cardio: mejora resistencia y salud cardiovascular (3-5 veces/semana)
                   • Fuerza: aumenta masa muscular y metabolismo (2-3 veces/semana)
                   • Flexibilidad: previene lesiones y mejora rango de movimiento
                   • HIIT: entrenamientos intensos cortos para mejorar resistencia y quemar grasa
                
                2. Nutrición para rendimiento:
                   • Carbohidratos: principal fuente de energía para ejercicio
                   • Proteínas: reparación y crecimiento muscular (1.2-2g/kg de peso)
                   • Grasas saludables: procesos hormonales y antiinflamatorios
                   • Hidratación: fundamental antes, durante y después del ejercicio
                
                3. Recuperación:
                   • Descanso adecuado entre sesiones intensas
                   • Sueño de calidad (7-9 horas)
                   • Técnicas de recuperación activa (estiramientos, yoga, etc.)
                   • Gestión del estrés para optimizar resultados
                
                4. Progresión:
                   • Principio de sobrecarga progresiva (aumentar gradualmente)
                   • Variar entrenamientos para evitar estancamientos
                   • Establecer metas específicas, medibles y realistas
                   • Considerar un entrenador para técnica correcta
                
                Recuerda: La consistencia superará siempre a la intensidad ocasional.
                """.trimIndent()
            }
            else -> "Selecciona un objetivo para ver consejos personalizados."
        }
    }

    private fun showMoreTipsDialog(goalType: String) {
        // Obtener IMC actual si está disponible
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val bmi = prefs.getFloat(KEY_BMI, 0f)

        // Mostrar diálogo con consejos detallados
        val detailedTips = getDetailedTipsForGoal(goalType, bmi)

        AlertDialog.Builder(this)
            .setTitle("Consejos para ${goalType.toLowerCase()}")
            .setMessage(detailedTips)
            .setPositiveButton("Entendido", null)
            .show()
    }

    companion object {
        const val PREFS_NAME = "user_profile"
        const val PROGRESS_PREFS = "user_progress"

        // Keys para SharedPreferences
        const val KEY_WEIGHT = "weight"
        const val KEY_HEIGHT = "height"
        const val KEY_AGE = "age"
        const val KEY_GOAL = "goal_index"
        const val KEY_GOAL_TEXT = "goal_text"
        const val KEY_BMI = "bmi"
        const val KEY_LAST_UPDATE = "last_update"
        const val KEY_WEIGHT_HISTORY = "weight_history"
    }
}