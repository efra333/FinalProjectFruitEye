package com.example.fruiteyeapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Inicialización mejorada de Firebase Auth
        auth = Firebase.auth

        // Verificación de sesión existente
        checkCurrentUser()

        // Configuración de vistas
        setupViews()
    }

    private fun checkCurrentUser() {
        auth.currentUser?.let {
            navigateToMainActivity()
        }
    }

    private fun setupViews() {
        val emailInput = findViewById<TextInputEditText>(R.id.et_email)
        val passwordInput = findViewById<TextInputEditText>(R.id.et_password)
        val btnLogin = findViewById<Button>(R.id.btn_login)
        val tvGoToRegister = findViewById<TextView>(R.id.tv_go_to_register)

        btnLogin.setOnClickListener {
            val email = emailInput.text.toString().trim()
            val password = passwordInput.text.toString().trim()

            when {
                email.isEmpty() -> showToast("Ingresa tu correo electrónico")
                password.isEmpty() -> showToast("Ingresa tu contraseña")
                !isValidEmail(email) -> showToast("Correo electrónico no válido")
                else -> authenticateUser(email, password)
            }
        }

        tvGoToRegister.setOnClickListener {
            navigateToRegister()
        }
    }

    private fun authenticateUser(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    onLoginSuccess()
                } else {
                    handleLoginError(task.exception)
                }
            }
    }

    private fun onLoginSuccess() {
        showToast("¡Inicio de sesión exitoso!")
        navigateToMainActivity()
    }

    private fun handleLoginError(exception: Exception?) {
        val errorMessage = when {
            exception?.message?.contains("invalid credential") == true -> {
                "Credenciales incorrectas"
            }
            exception?.message?.contains("no user record") == true -> {
                "Usuario no registrado"
            }
            exception?.message?.contains("network error") == true -> {
                "Error de conexión. Verifica tu internet"
            }
            else -> "Error al iniciar sesión: ${exception?.message ?: "Inténtalo más tarde"}"
        }
        showToast(errorMessage)
    }

    // Helper functions
    private fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun navigateToMainActivity() {
        startActivity(Intent(this, MealManagementActivity::class.java))
        finishAffinity() // Limpia el back stack
    }

    private fun navigateToRegister() {
        startActivity(Intent(this, RegisterActivity::class.java))
        // No llamamos a finish() para permitir volver atrás si es necesario
    }
}