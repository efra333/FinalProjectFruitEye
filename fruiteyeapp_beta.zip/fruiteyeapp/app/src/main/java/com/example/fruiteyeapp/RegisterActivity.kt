package com.example.fruiteyeapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class RegisterActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // Inicializar Firebase Auth
        auth = Firebase.auth

        // Referencias a los views
        val nameInput = findViewById<TextInputEditText>(R.id.et_name)
        val emailInput = findViewById<TextInputEditText>(R.id.et_email)
        val passwordInput = findViewById<TextInputEditText>(R.id.et_password)
        val confirmPasswordInput = findViewById<TextInputEditText>(R.id.et_confirm_password)
        val btnRegister = findViewById<Button>(R.id.btn_register)
        val tvLoginLink = findViewById<TextView>(R.id.tv_login_link)

        // Listener para el botón de registro
        btnRegister.setOnClickListener {
            val name = nameInput.text.toString().trim()
            val email = emailInput.text.toString().trim()
            val password = passwordInput.text.toString().trim()
            val confirmPassword = confirmPasswordInput.text.toString().trim()

            if (validateInputs(name, email, password, confirmPassword)) {
                registerUser(name, email, password)
            }
        }

        // Listener para el enlace de login - CORREGIDO
        tvLoginLink.setOnClickListener {
            // Navegación simple a LoginActivity
            startActivity(Intent(this, LoginActivity::class.java))
            // No llamamos a finish() aquí para mantener la coherencia con el comportamiento en LoginActivity
        }
    }

    private fun validateInputs(
        name: String,
        email: String,
        password: String,
        confirmPassword: String
    ): Boolean {
        return when {
            name.isEmpty() -> {
                showToast("Por favor ingresa tu nombre")
                false
            }
            email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() -> {
                showToast("Ingresa un correo electrónico válido")
                false
            }
            password.isEmpty() || password.length < 6 -> {
                showToast("La contraseña debe tener al menos 6 caracteres")
                false
            }
            password != confirmPassword -> {
                showToast("Las contraseñas no coinciden")
                false
            }
            else -> true
        }
    }

    private fun registerUser(name: String, email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Actualizar perfil con el nombre
                    val user = auth.currentUser
                    val profileUpdates = UserProfileChangeRequest.Builder()
                        .setDisplayName(name)
                        .build()

                    user?.updateProfile(profileUpdates)
                        ?.addOnCompleteListener { profileTask ->
                            val message = if (profileTask.isSuccessful) {
                                "¡Registro exitoso! Por favor inicia sesión"
                            } else {
                                "Registro exitoso, pero no se pudo guardar el nombre"
                            }
                            showToast(message)

                            // Asegurarse de que el usuario esté desconectado para forzar el inicio de sesión
                            auth.signOut()
                            navigateToLogin()
                        }
                } else {
                    handleRegistrationError(task.exception)
                }
            }
    }

    private fun handleRegistrationError(exception: Exception?) {
        val errorMessage = when {
            exception?.message?.contains("email address is already in use") == true -> {
                "El correo ya está registrado"
            }
            exception?.message?.contains("password is invalid") == true -> {
                "La contraseña es demasiado débil"
            }
            exception?.message?.contains("network error") == true -> {
                "Error de conexión. Verifica tu internet"
            }
            else -> "Error al registrar: ${exception?.message ?: "Inténtalo más tarde"}"
        }
        showToast(errorMessage)
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun navigateToLogin() {
        // Navegación simple a LoginActivity después del registro exitoso
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish() // Cerramos esta actividad para que no puedan volver atrás después del registro
    }
}