package com.example.fruiteyeapp

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MealRepository(context: Context) {
    private val dbHelper = DatabaseHelper(context)

    suspend fun insertMeal(meal: Meal) = withContext(Dispatchers.IO) {
        dbHelper.insertMeal(meal)
    }

    suspend fun getMealsForDay(startOfDay: Long) = withContext(Dispatchers.IO) {
        dbHelper.getMealsForDay(startOfDay)
    }

    suspend fun deleteMeal(mealId: Int) = withContext(Dispatchers.IO) {
        dbHelper.deleteMeal(mealId)
    }

    suspend fun deleteMealsByType(mealType: String) = withContext(Dispatchers.IO) {
        dbHelper.deleteMealsByType(mealType)
    }
}