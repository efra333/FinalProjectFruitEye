package com.example.fruiteyeapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "meal_database.db"
        private const val DATABASE_VERSION = 1
        const val TABLE_MEALS = "meals"
        const val COLUMN_ID = "id"
        const val COLUMN_MEAL_TYPE = "mealType"
        const val COLUMN_DESCRIPTION = "description"
        const val COLUMN_CALORIES = "calories"
        const val COLUMN_DATE = "date"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE $TABLE_MEALS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_MEAL_TYPE TEXT NOT NULL,
                $COLUMN_DESCRIPTION TEXT NOT NULL,
                $COLUMN_CALORIES INTEGER NOT NULL,
                $COLUMN_DATE INTEGER NOT NULL
            )
        """.trimIndent()
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_MEALS")
        onCreate(db)
    }

    fun insertMeal(meal: Meal): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_MEAL_TYPE, meal.mealType)
            put(COLUMN_DESCRIPTION, meal.description)
            put(COLUMN_CALORIES, meal.calories)
            put(COLUMN_DATE, meal.date)
        }
        return db.insert(TABLE_MEALS, null, values)
    }

    fun getMealsForDay(startOfDay: Long): List<Meal> {
        val db = readableDatabase
        val meals = mutableListOf<Meal>()
        val cursor = db.query(
            TABLE_MEALS,
            null,
            "$COLUMN_DATE >= ?",
            arrayOf(startOfDay.toString()),
            null,
            null,
            "$COLUMN_DATE DESC"  // Ordenar por fecha descendente
        )

        cursor.use {
            while (it.moveToNext()) {
                val meal = Meal(
                    id = it.getInt(it.getColumnIndexOrThrow(COLUMN_ID)),
                    mealType = it.getString(it.getColumnIndexOrThrow(COLUMN_MEAL_TYPE)),
                    description = it.getString(it.getColumnIndexOrThrow(COLUMN_DESCRIPTION)),
                    calories = it.getInt(it.getColumnIndexOrThrow(COLUMN_CALORIES)),
                    date = it.getLong(it.getColumnIndexOrThrow(COLUMN_DATE))
                )
                meals.add(meal)
            }
        }
        return meals
    }

    fun deleteMeal(mealId: Int): Int {
        val db = writableDatabase
        return db.delete(
            TABLE_MEALS,
            "$COLUMN_ID = ?",
            arrayOf(mealId.toString())
        )
    }

    fun deleteMealsByType(mealType: String): Int {
        val db = writableDatabase
        return db.delete(
            TABLE_MEALS,
            "$COLUMN_MEAL_TYPE = ?",
            arrayOf(mealType)
        )
    }

    fun getCalorieSummary(startOfDay: Long): List<CalorieSummary> {
        val db = readableDatabase
        val summaries = mutableListOf<CalorieSummary>()

        val query = """
            SELECT $COLUMN_MEAL_TYPE, SUM($COLUMN_CALORIES) as totalCalories 
            FROM $TABLE_MEALS 
            WHERE $COLUMN_DATE >= $startOfDay 
            GROUP BY $COLUMN_MEAL_TYPE
        """.trimIndent()

        val cursor = db.rawQuery(query, null)
        cursor.use {
            while (it.moveToNext()) {
                val mealType = it.getString(it.getColumnIndexOrThrow(COLUMN_MEAL_TYPE))
                val totalCalories = it.getInt(it.getColumnIndexOrThrow("totalCalories"))

                val mealsQuery = """
                    SELECT * 
                    FROM $TABLE_MEALS 
                    WHERE $COLUMN_MEAL_TYPE = ? AND $COLUMN_DATE >= ?
                """.trimIndent()
                val mealsCursor = db.rawQuery(mealsQuery, arrayOf(mealType, startOfDay.toString()))
                val meals = mutableListOf<Meal>()

                mealsCursor.use { cursorMeals ->
                    while (cursorMeals.moveToNext()) {
                        val meal = Meal(
                            id = cursorMeals.getInt(cursorMeals.getColumnIndexOrThrow(COLUMN_ID)),
                            mealType = cursorMeals.getString(cursorMeals.getColumnIndexOrThrow(COLUMN_MEAL_TYPE)),
                            description = cursorMeals.getString(cursorMeals.getColumnIndexOrThrow(COLUMN_DESCRIPTION)),
                            calories = cursorMeals.getInt(cursorMeals.getColumnIndexOrThrow(COLUMN_CALORIES)),
                            date = cursorMeals.getLong(cursorMeals.getColumnIndexOrThrow(COLUMN_DATE))
                        )
                        meals.add(meal)
                    }
                }

                summaries.add(CalorieSummary(
                    mealType = mealType,
                    meals = meals,
                    totalCalories = totalCalories
                ))
            }
        }
        return summaries
    }
}