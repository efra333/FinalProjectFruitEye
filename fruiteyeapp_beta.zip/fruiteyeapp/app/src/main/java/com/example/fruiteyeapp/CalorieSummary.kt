package com.example.fruiteyeapp
data class CalorieSummary(
    val mealType: String,
    val meals: List<Meal>,
    val totalCalories: Int
)
