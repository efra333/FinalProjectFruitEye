package com.example.fruiteyeapp

import java.util.*

/**
 * Clase modelo para el perfil del usuario
 */
data class UserProfile(
    val weight: Float,
    val height: Int,
    val age: Int,
    val goalType: String,
    val bmi: Float,
    val lastUpdate: Date = Date()
) {
    fun getBmiCategory(): String {
        return when {
            bmi < 18.5 -> "Bajo peso"
            bmi < 25 -> "Peso normal"
            bmi < 30 -> "Sobrepeso"
            else -> "Obesidad"
        }
    }

    fun getHealthStatus(): String {
        // Lógica simplificada para determinar el estado de salud
        return when {
            bmi < 18.5 -> "Necesitas aumentar de peso"
            bmi < 25 -> "¡Excelente! Mantenlo así"
            bmi < 30 -> "Considera reducir un poco tu peso"
            else -> "Consulta a un nutricionista para un plan de alimentación"
        }
    }
}