package com.example.fruiteyeapp

data class Meal(
    val id: Int = 0,
    val mealType: String,
    val description: String,
    val calories: Int,
    val photoUri: String? = null,
    val date: Long = System.currentTimeMillis()
)
