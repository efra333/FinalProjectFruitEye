package com.example.fruiteyeapp

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.InputStream

class MainActivity : AppCompatActivity() {

    private val PICK_IMAGE_REQUEST = 1
    private lateinit var imageView: ImageView
    private lateinit var resultText: TextView
    private val apiKey = "kAeCQ5leWbAIzElqgxtM"
    private val modelURL = "https://detect.roboflow.com/fruits_det-ursdl/4?api_key=$apiKey"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val galleryButton: Button = findViewById(R.id.galleryButton)
        val captureButton: Button = findViewById(R.id.captureButton)
        imageView = findViewById(R.id.imageView)
        resultText = findViewById(R.id.resultText)

        galleryButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, PICK_IMAGE_REQUEST)
        }

        captureButton.setOnClickListener {
            // no se como meter para que se abra la camara y se tome la foto pero iria aqui
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            val imageUri: Uri? = data.data
            imageUri?.let {
                imageView.setImageURI(it)
                val imageFile = getFileFromUri(it)
                imageFile?.let { file -> uploadImageToRoboflow(file) }
            }
        }
    }

    private fun getFileFromUri(uri: Uri): File? {
        val inputStream: InputStream? = contentResolver.openInputStream(uri)
        val file = File(cacheDir, "selectedImage.jpg")
        inputStream?.use { input ->
            file.outputStream().use { output ->
                input.copyTo(output)
            }
        }
        return file
    }

    private fun uploadImageToRoboflow(imageFile: File) {
        val client = OkHttpClient()
        val mediaType = "image/*".toMediaTypeOrNull()
        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", imageFile.name, imageFile.asRequestBody(mediaType))
            .build()

        val request = Request.Builder()
            .url(modelURL)
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    resultText.text = "Error: ${e.message}"
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string()
                val json = JSONObject(responseBody ?: "{}")
                val predictions = json.optJSONArray("predictions")
                val resultado = StringBuilder()

                for (i in 0 until (predictions?.length() ?: 0)) {
                    val pred = predictions!!.getJSONObject(i)
                    val clase = pred.getString("class")
                    if ("-" in clase) {
                        val partes = clase.split("-")
                        val nombre = partes[0].trim()
                        val calorias = partes[1].replace("calories", "").trim()
                        resultado.append("Fruta: $nombre\nCalorías: $calorias\n\n")
                    } else {
                        resultado.append("Clase detectada: $clase\n\n")
                    }
                }

                runOnUiThread {
                    resultText.text = resultado.toString().ifEmpty { "Sin detecciones." }
                }
            }
        })
    }
}